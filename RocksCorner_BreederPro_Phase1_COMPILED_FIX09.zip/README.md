Rocks Corner Breeder Pro - Phase 1 (Compiled)

This build combines the full-sheet Phase 1 UI with working Add Dog sheet and supporting assets.
