/* Breeder Pro v2.1 — Breeder/Seller/Buyer hats.
   Local-first. Public page is static (public.html) fed by exported JSON.
*/
const STORAGE_KEY="breeder_pro_v2_1";
const nowISO=()=>new Date().toISOString();
const uid=()=>Math.random().toString(16).slice(2)+"-"+Date.now().toString(16);
const safeParse=(j,f)=>{try{return JSON.parse(j)}catch{return f}};
const esc=(s)=>String(s??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");
const inc=(h,n)=>String(h??"").toLowerCase().includes(String(n??"").toLowerCase());
const fmt=(iso)=>{if(!iso) return "—"; try{const d=new Date(iso); return isNaN(d)?iso:d.toLocaleDateString()}catch{return iso}};

function defaultState(){
  return {
    meta:{version:"2.1",createdAt:nowISO(),updatedAt:nowISO()},
    kennel:{name:"Breeder Pro",mode:"Breeder",initials:"BP",color:"#7dd3fc"},
    hats:{breeder:"On",seller:"On",buyer:"On"},
    breeds:[{id:"gsp",name:"German Shorthaired Pointer",active:true}],
    dogs:[], litters:[],
    listings:[], inquiries:[],
    waitlist:[], buyerPurchases:[],
    contacts:[] // unified contacts (clients + buyers/sellers)
  };
}
let state=load();
function load(){
  const raw=localStorage.getItem(STORAGE_KEY);
  const s=raw?safeParse(raw,null):null;
  if(!s||!s.meta||!Array.isArray(s.breeds)) return defaultState();
  if(!s.breeds.some(b=>b.id==="gsp"||b.name==="German Shorthaired Pointer")) s.breeds.unshift({id:"gsp",name:"German Shorthaired Pointer",active:true});
  s.kennel=s.kennel||defaultState().kennel;
  s.hats=s.hats||defaultState().hats;
  for(const k of ["dogs","litters","listings","inquiries","waitlist","buyerPurchases","contacts"]) s[k]=Array.isArray(s[k])?s[k]:[];
  return s;
}
function save(){ state.meta.updatedAt=nowISO(); localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); renderAll(); }

// Tabs
const views=["dashboardView","breederView","sellerView","buyerView","settingsView"];
document.querySelectorAll(".tab").forEach(btn=>{
  btn.addEventListener("click",()=>{
    document.querySelectorAll(".tab").forEach(b=>b.classList.remove("active"));
    btn.classList.add("active");
    const id=btn.dataset.view;
    views.forEach(v=>document.getElementById(v).classList.toggle("active", v===id));
  });
});

// PWA
let deferredPrompt=null; const btnInstall=document.getElementById("btnInstall");
window.addEventListener("beforeinstallprompt",(e)=>{ e.preventDefault(); deferredPrompt=e; btnInstall.hidden=false; });
btnInstall?.addEventListener("click",async()=>{ if(!deferredPrompt) return; deferredPrompt.prompt(); await deferredPrompt.userChoice; deferredPrompt=null; btnInstall.hidden=true; });
if("serviceWorker" in navigator){ window.addEventListener("load",()=>{ navigator.serviceWorker.register("./service-worker.js").catch(()=>{}); }); }

// Branding
const brandTitle=document.getElementById("brandTitle");
const brandSubtitle=document.getElementById("brandSubtitle");
const logoEl=document.querySelector(".logo");
function applyBrand(){
  const k=state.kennel||defaultState().kennel;
  brandTitle.textContent=k.name||"Breeder Pro";
  brandSubtitle.textContent=(k.mode||"Breeder")+" dashboard";
  if(logoEl) logoEl.textContent=(k.initials||"BP").slice(0,4).toUpperCase();
  const color=(k.color||"#7dd3fc").trim();
  if(/^#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})$/.test(color)) document.documentElement.style.setProperty("--brand", color);
}

// Hats UI
const hatBreeder=document.getElementById("hatBreeder");
const hatSeller=document.getElementById("hatSeller");
const hatBuyer=document.getElementById("hatBuyer");
const btnSaveHats=document.getElementById("btnSaveHats");
function applyHats(){
  // hide/show tabs
  const map={breederView:"breeder", sellerView:"seller", buyerView:"buyer"};
  document.querySelectorAll(".tab").forEach(btn=>{
    const v=btn.dataset.view;
    if(map[v]){
      const on=state.hats?.[map[v]]!=="Off";
      btn.style.display = on ? "" : "none";
    }
  });
}
btnSaveHats?.addEventListener("click",()=>{
  state.hats={breeder:hatBreeder.value, seller:hatSeller.value, buyer:hatBuyer.value};
  save();
  alert("Hats saved ✅");
});

// Breeds
const dogBreed=document.getElementById("dogBreed");
const litterBreed=document.getElementById("litterBreed");
const waitBreed=document.getElementById("waitBreed");
const bpBreed=document.getElementById("bpBreed");
const listingBreed=document.getElementById("listingBreed");
const dogsBreedFilter=document.getElementById("dogsBreedFilter");

const activeBreeds=()=>state.breeds.filter(b=>b.active!==false);
const breedNameById=(id)=>{ const b=state.breeds.find(x=>x.id===id); return b?b.name:(id||"—"); };

function fillBreedSelects(){
  const breeds=activeBreeds();
  const opts=breeds.map(b=>`<option value="${esc(b.id)}">${esc(b.name)}</option>`).join("");
  for(const el of [dogBreed,litterBreed,waitBreed,bpBreed,listingBreed]) if(el) el.innerHTML=opts;
  if(dogsBreedFilter){
    dogsBreedFilter.innerHTML=`<option value="__all__">All breeds</option>`+opts;
    if(!dogsBreedFilter.value) dogsBreedFilter.value="__all__";
  }
}

// Dogs
const dogForm=document.getElementById("dogForm");
const dogName=document.getElementById("dogName");
const dogSex=document.getElementById("dogSex");
const dogDob=document.getElementById("dogDob");
const dogReg=document.getElementById("dogReg");
const dogStatus=document.getElementById("dogStatus");
const dogNotes=document.getElementById("dogNotes");
const btnDogClear=document.getElementById("btnDogClear");
const dogsList=document.getElementById("dogsList");
const dogsSearch=document.getElementById("dogsSearch");
btnDogClear?.addEventListener("click",()=>dogForm?.reset());
dogsSearch?.addEventListener("input",()=>renderDogs());
dogsBreedFilter?.addEventListener("change",()=>renderDogs());

dogForm?.addEventListener("submit",(e)=>{
  e.preventDefault();
  const item={id:uid(),name:dogName.value.trim(),breedId:dogBreed.value,sex:dogSex.value,dob:dogDob.value||"",
    akcReg:dogReg.value.trim(),status:dogStatus.value,notes:dogNotes.value.trim(),createdAt:nowISO(),updatedAt:nowISO()};
  if(!item.name) return;
  state.dogs.unshift(item);
  dogForm.reset(); dogSex.value="Male"; dogStatus.value="Breeding Stock";
  save();
});
function updateDog(id,patch){ const i=state.dogs.findIndex(d=>d.id===id); if(i<0) return; state.dogs[i]={...state.dogs[i],...patch,updatedAt:nowISO()}; save(); }
function deleteDog(id){ state.dogs=state.dogs.filter(d=>d.id!==id); save(); }

function dogOptionsBySex(sex){
  const list=state.dogs.filter(d=>d.sex===sex);
  const opts=['<option value="">(none)</option>'].concat(list.map(d=>`<option value="${esc(d.id)}">${esc(d.name)}${d.akcReg?` (${esc(d.akcReg)})`:""}</option>`));
  return opts.join("");
}

// Litters (with dam/sire select)
const litterForm=document.getElementById("litterForm");
const litterDob=document.getElementById("litterDob");
const litterDamDog=document.getElementById("litterDamDog");
const litterSireDog=document.getElementById("litterSireDog");
const litterMale=document.getElementById("litterMale");
const litterFemale=document.getElementById("litterFemale");
const litterNotes=document.getElementById("litterNotes");
const btnLitterClear=document.getElementById("btnLitterClear");
const littersList=document.getElementById("littersList");
btnLitterClear?.addEventListener("click",()=>litterForm?.reset());

function refreshParentSelects(){
  if(litterDamDog) litterDamDog.innerHTML = dogOptionsBySex("Female");
  if(litterSireDog) litterSireDog.innerHTML = dogOptionsBySex("Male");
}

litterForm?.addEventListener("submit",(e)=>{
  e.preventDefault();
  const damId=litterDamDog.value||"";
  const sireId=litterSireDog.value||"";
  const dam=damId?state.dogs.find(d=>d.id===damId)?.name||"": "";
  const sire=sireId?state.dogs.find(d=>d.id===sireId)?.name||"": "";
  const item={id:uid(),breedId:litterBreed.value,birthDate:litterDob.value,damId, sireId, dam, sire,
    maleCount:Number(litterMale.value||0),femaleCount:Number(litterFemale.value||0),notes:litterNotes.value.trim(),createdAt:nowISO(),updatedAt:nowISO()};
  if(!item.birthDate) return;
  state.litters.unshift(item); litterForm.reset(); litterMale.value=0; litterFemale.value=0; save();
});
function updateLitter(id,patch){ const i=state.litters.findIndex(x=>x.id===id); if(i<0) return; state.litters[i]={...state.litters[i],...patch,updatedAt:nowISO()}; save(); }
function deleteLitter(id){ state.litters=state.litters.filter(x=>x.id!==id); save(); }

function renderDogs(){
  if(!dogsList) return;
  const q=(dogsSearch?.value||"").trim();
  const bf=dogsBreedFilter?.value||"__all__";
  const list=state.dogs.filter(d=>{ if(bf!=="__all__"&&d.breedId!==bf) return false; if(!q) return true;
    return inc(d.name,q)||inc(d.akcReg,q)||inc(d.notes,q)||inc(d.status,q); });
  dogsList.innerHTML=list.map(d=>`
    <div class="item">
      <div class="item-head">
        <div>
          <div class="item-title">${esc(d.name)}</div>
          <div class="item-sub">${esc(breedNameById(d.breedId))} • ${esc(d.sex)} • DOB: ${esc(fmt(d.dob))} • ${esc(d.status)}</div>
          ${d.akcReg?`<div class="small muted" style="margin-top:6px">AKC Reg: ${esc(d.akcReg)}</div>`:""}
        </div>
        <div class="badges">
          <span class="badge brand">${esc(d.sex)}</span>
          <span class="badge">${esc(d.status)}</span>
        </div>
      </div>
      ${d.notes?`<div class="small muted" style="margin-top:8px;">${esc(d.notes)}</div>`:""}
      <div class="hr"></div>
      <div class="grid">
        <label>Status
          <select class="input" data-action="dogStatus" data-id="${d.id}">
            ${["Breeding Stock","Retained","Available","Placed","Other"].map(s=>`<option ${s===d.status?"selected":""}>${s}</option>`).join("")}
          </select>
        </label>
        <label>Notes<input class="input" data-action="dogNotes" data-id="${d.id}" value="${esc(d.notes||"")}" /></label>
        <label class="span2">AKC Registration #<input class="input" data-action="dogReg" data-id="${d.id}" value="${esc(d.akcReg||"")}" /></label>
        <div class="span2 actions"><button class="btn danger" data-action="dogDelete" data-id="${d.id}" type="button">Delete</button></div>
      </div>
    </div>
  `).join("")||`<div class="muted">No dogs yet.</div>`;
  dogsList.querySelectorAll("[data-action='dogStatus']").forEach(sel=>sel.addEventListener("change",(e)=>updateDog(sel.dataset.id,{status:e.target.value})));
  dogsList.querySelectorAll("[data-action='dogNotes']").forEach(inp=>inp.addEventListener("change",(e)=>updateDog(inp.dataset.id,{notes:e.target.value.trim()})));
  dogsList.querySelectorAll("[data-action='dogReg']").forEach(inp=>inp.addEventListener("change",(e)=>updateDog(inp.dataset.id,{akcReg:e.target.value.trim()})));
  dogsList.querySelectorAll("[data-action='dogDelete']").forEach(btn=>btn.addEventListener("click",()=>deleteDog(btn.dataset.id)));
  refreshParentSelects();
}

function renderLitters(){
  if(!littersList) return;
  littersList.innerHTML=state.litters.map(l=>`
    <div class="item">
      <div class="item-head">
        <div>
          <div class="item-title">${esc(fmt(l.birthDate))}</div>
          <div class="item-sub">${esc(breedNameById(l.breedId))} • Dam: ${esc(l.dam||"—")} • Sire: ${esc(l.sire||"—")}</div>
        </div>
        <div class="badges">
          <span class="badge ok">♂ ${esc(l.maleCount)}</span>
          <span class="badge brand">♀ ${esc(l.femaleCount)}</span>
        </div>
      </div>
      ${l.notes?`<div class="small muted" style="margin-top:8px;">${esc(l.notes)}</div>`:""}
      <div class="hr"></div>
      <div class="actions"><button class="btn danger" data-action="lDelete" data-id="${l.id}" type="button">Delete</button></div>
    </div>
  `).join("")||`<div class="muted">No litters yet.</div>`;
  littersList.querySelectorAll("[data-action='lDelete']").forEach(btn=>btn.addEventListener("click",()=>deleteLitter(btn.dataset.id)));
}

// Seller: listings + inquiries
const listingForm=document.getElementById("listingForm");
const listingType=document.getElementById("listingType");
const listingTitle=document.getElementById("listingTitle");
const listingPrice=document.getElementById("listingPrice");
const listingDesc=document.getElementById("listingDesc");
const listingStatus=document.getElementById("listingStatus");
const listingPublic=document.getElementById("listingPublic");
const sellerSearch=document.getElementById("sellerSearch");
const listingsList=document.getElementById("listingsList");
const inquiriesList=document.getElementById("inquiriesList");
const inquiryForm=document.getElementById("inquiryForm");
const inquiryListing=document.getElementById("inquiryListing");
const inquiryName=document.getElementById("inquiryName");
const inquiryEmail=document.getElementById("inquiryEmail");
const inquiryPhone=document.getElementById("inquiryPhone");
const inquiryMsg=document.getElementById("inquiryMsg");

sellerSearch?.addEventListener("input",()=>{renderListings(); renderInquiries();});

listingForm?.addEventListener("submit",(e)=>{
  e.preventDefault();
  const item={id:uid(),type:listingType.value,breedId:listingBreed.value,title:listingTitle.value.trim(),
    price:Number(listingPrice.value||0),desc:listingDesc.value.trim(),status:listingStatus.value,public:listingPublic.value,
    createdAt:nowISO(),updatedAt:nowISO()};
  if(!item.title) return;
  state.listings.unshift(item);
  listingForm.reset(); listingStatus.value="Active"; listingPublic.value="Yes";
  save();
});

function deleteListing(id){ state.listings=state.listings.filter(x=>x.id!==id); save(); }
function fillInquiryListing(){
  if(!inquiryListing) return;
  const opts = state.listings.map(l=>`<option value="${esc(l.id)}">${esc(l.title)} (${esc(l.status)})</option>`).join("");
  inquiryListing.innerHTML = opts || `<option value="">(no listings)</option>`;
}

inquiryForm?.addEventListener("submit",(e)=>{
  e.preventDefault();
  const listingId=inquiryListing.value;
  const item={id:uid(),listingId,listingTitle:state.listings.find(l=>l.id===listingId)?.title||"",
    name:inquiryName.value.trim(),email:inquiryEmail.value.trim(),phone:inquiryPhone.value.trim(),message:inquiryMsg.value.trim(),
    status:"New",createdAt:nowISO(),updatedAt:nowISO()};
  state.inquiries.unshift(item);
  inquiryForm.reset();
  save();
});

function updateInquiry(id,patch){ const i=state.inquiries.findIndex(x=>x.id===id); if(i<0) return; state.inquiries[i]={...state.inquiries[i],...patch,updatedAt:nowISO()}; save(); }
function deleteInquiry(id){ state.inquiries=state.inquiries.filter(x=>x.id!==id); save(); }

function renderListings(){
  if(!listingsList) return;
  const q=(sellerSearch?.value||"").trim();
  const list=state.listings.filter(l=>!q || inc(l.title,q)||inc(l.desc,q)||inc(l.status,q)||inc(breedNameById(l.breedId),q));
  listingsList.innerHTML=list.map(l=>`
    <div class="item">
      <div class="item-head">
        <div>
          <div class="item-title">${esc(l.title)}</div>
          <div class="item-sub">${esc(l.type)} • ${esc(breedNameById(l.breedId))} • ${esc(l.status)} • ${l.public==="Yes"?"Public":"Private"} ${l.price?`• $${esc(l.price)}`:""}</div>
        </div>
        <div class="badges"><span class="badge ${l.status==="Active"?"brand":""}">${esc(l.status)}</span></div>
      </div>
      ${l.desc?`<div class="small muted" style="margin-top:8px;">${esc(l.desc)}</div>`:""}
      <div class="hr"></div>
      <div class="actions"><button class="btn danger" type="button" data-action="delListing" data-id="${l.id}">Delete</button></div>
    </div>
  `).join("")||`<div class="muted">No listings yet.</div>`;
  listingsList.querySelectorAll("[data-action='delListing']").forEach(btn=>btn.addEventListener("click",()=>deleteListing(btn.dataset.id)));
  fillInquiryListing();
}

function renderInquiries(){
  if(!inquiriesList) return;
  const q=(sellerSearch?.value||"").trim();
  const list=state.inquiries.filter(i=>!q || inc(i.name,q)||inc(i.email,q)||inc(i.phone,q)||inc(i.message,q)||inc(i.listingTitle,q)||inc(i.status,q));
  inquiriesList.innerHTML=list.map(i=>`
    <div class="item">
      <div class="item-head">
        <div>
          <div class="item-title">${esc(i.name||"Inquiry")}</div>
          <div class="item-sub">${esc(i.email||"—")} • ${esc(i.phone||"—")} • Listing: ${esc(i.listingTitle||"—")}</div>
        </div>
        <div class="badges"><span class="badge ${i.status==="New"?"brand":""}">${esc(i.status)}</span></div>
      </div>
      ${i.message?`<div class="small muted" style="margin-top:8px;">${esc(i.message)}</div>`:""}
      <div class="hr"></div>
      <div class="grid">
        <label>Status
          <select class="input" data-action="inqStatus" data-id="${i.id}">
            ${["New","Replied","Qualified","Reserved","Closed"].map(s=>`<option ${s===i.status?"selected":""}>${s}</option>`).join("")}
          </select>
        </label>
        <label>Notes
          <input class="input" data-action="inqMsg" data-id="${i.id}" value="${esc(i.message||"")}" />
        </label>
        <div class="span2 actions">
          <button class="btn danger" type="button" data-action="delInquiry" data-id="${i.id}">Delete</button>
        </div>
      </div>
    </div>
  `).join("")||`<div class="muted">No inquiries yet.</div>`;
  inquiriesList.querySelectorAll("[data-action='inqStatus']").forEach(sel=>sel.addEventListener("change",(e)=>updateInquiry(sel.dataset.id,{status:e.target.value})));
  inquiriesList.querySelectorAll("[data-action='inqMsg']").forEach(inp=>inp.addEventListener("change",(e)=>updateInquiry(inp.dataset.id,{message:e.target.value.trim()})));
  inquiriesList.querySelectorAll("[data-action='delInquiry']").forEach(btn=>btn.addEventListener("click",()=>deleteInquiry(btn.dataset.id)));
}

// Buyer: waitlist + purchases
const waitForm=document.getElementById("waitForm");
const waitName=document.getElementById("waitName");
const waitSex=document.getElementById("waitSex");
const waitTiming=document.getElementById("waitTiming");
const waitPhone=document.getElementById("waitPhone");
const waitEmail=document.getElementById("waitEmail");
const waitTraits=document.getElementById("waitTraits");
const waitNotes=document.getElementById("waitNotes");
const waitList=document.getElementById("waitList");
const buyerSearch=document.getElementById("buyerSearch");

buyerSearch?.addEventListener("input",()=>{renderWaitlist(); renderBuyerPurchases();});

waitForm?.addEventListener("submit",(e)=>{
  e.preventDefault();
  const item={id:uid(),name:waitName.value.trim(),desiredBreedId:waitBreed.value,desiredSex:waitSex.value,desiredTiming:waitTiming.value.trim(),
    phone:waitPhone.value.trim(),email:waitEmail.value.trim(),traits:waitTraits.value.trim(),notes:waitNotes.value.trim(),
    status:"Waiting",createdAt:nowISO(),updatedAt:nowISO()};
  if(!item.name) return;
  state.waitlist.unshift(item); waitForm.reset(); waitSex.value="Any"; save();
});
function updateWait(id,patch){ const i=state.waitlist.findIndex(x=>x.id===id); if(i<0) return; state.waitlist[i]={...state.waitlist[i],...patch,updatedAt:nowISO()}; save(); }
function deleteWait(id){ state.waitlist=state.waitlist.filter(x=>x.id!==id); save(); }

function renderWaitlist(){
  if(!waitList) return;
  const q=(buyerSearch?.value||"").trim();
  const list=state.waitlist.filter(w=>!q || inc(w.name,q)||inc(w.phone,q)||inc(w.email,q)||inc(w.traits,q)||inc(w.notes,q)||inc(w.status,q));
  waitList.innerHTML=list.map(w=>`
    <div class="item">
      <div class="item-head">
        <div>
          <div class="item-title">${esc(w.name)}</div>
          <div class="item-sub">${esc(breedNameById(w.desiredBreedId))} • Wants: ${esc(w.desiredSex)} • Timing: ${esc(w.desiredTiming||"—")}</div>
          <div class="small muted" style="margin-top:6px">${esc(w.phone||"—")} • ${esc(w.email||"—")}</div>
        </div>
        <div class="badges"><span class="badge ${w.status==="Waiting"?"brand":""}">${esc(w.status)}</span></div>
      </div>
      ${w.traits?`<div class="small muted" style="margin-top:8px;">Traits: ${esc(w.traits)}</div>`:""}
      ${w.notes?`<div class="small muted" style="margin-top:4px;">Notes: ${esc(w.notes)}</div>`:""}
      <div class="hr"></div>
      <div class="grid">
        <label>Status
          <select class="input" data-action="wStatus" data-id="${w.id}">
            ${["Waiting","Contacted","Reserved","Closed"].map(s=>`<option ${s===w.status?"selected":""}>${s}</option>`).join("")}
          </select>
        </label>
        <label>Notes<input class="input" data-action="wNotes" data-id="${w.id}" value="${esc(w.notes||"")}" /></label>
        <div class="span2 actions"><button class="btn danger" type="button" data-action="wDelete" data-id="${w.id}">Delete</button></div>
      </div>
    </div>
  `).join("")||`<div class="muted">No waitlist entries yet.</div>`;
  waitList.querySelectorAll("[data-action='wStatus']").forEach(sel=>sel.addEventListener("change",(e)=>updateWait(sel.dataset.id,{status:e.target.value})));
  waitList.querySelectorAll("[data-action='wNotes']").forEach(inp=>inp.addEventListener("change",(e)=>updateWait(inp.dataset.id,{notes:e.target.value.trim()})));
  waitList.querySelectorAll("[data-action='wDelete']").forEach(btn=>btn.addEventListener("click",()=>deleteWait(btn.dataset.id)));
}

// Buyer purchases
const buyerPurchaseForm=document.getElementById("buyerPurchaseForm");
const bpSeller=document.getElementById("bpSeller");
const bpDog=document.getElementById("bpDog");
const bpDate=document.getElementById("bpDate");
const bpAmount=document.getElementById("bpAmount");
const bpNotes=document.getElementById("bpNotes");
const buyerPurchasesList=document.getElementById("buyerPurchasesList");

buyerPurchaseForm?.addEventListener("submit",(e)=>{
  e.preventDefault();
  const item={id:uid(),seller:bpSeller.value.trim(),breedId:bpBreed.value,dog:bpDog.value.trim()||"TBD",
    date:bpDate.value||new Date().toISOString().slice(0,10),amount:Number(bpAmount.value||0),notes:bpNotes.value.trim(),
    createdAt:nowISO(),updatedAt:nowISO()};
  state.buyerPurchases.unshift(item);
  buyerPurchaseForm.reset();
  save();
});
function deleteBuyerPurchase(id){ state.buyerPurchases=state.buyerPurchases.filter(x=>x.id!==id); save(); }
function renderBuyerPurchases(){
  if(!buyerPurchasesList) return;
  const q=(buyerSearch?.value||"").trim();
  const list=state.buyerPurchases.filter(p=>!q || inc(p.seller,q)||inc(p.dog,q)||inc(p.notes,q)||inc(breedNameById(p.breedId),q));
  buyerPurchasesList.innerHTML=list.map(p=>`
    <div class="item">
      <div class="item-title">${esc(p.dog)}</div>
      <div class="item-sub">${esc(breedNameById(p.breedId))} • From: ${esc(p.seller||"—")} • ${esc(fmt(p.date))} ${p.amount?`• $${esc(p.amount)}`:""}</div>
      ${p.notes?`<div class="small muted" style="margin-top:8px;">${esc(p.notes)}</div>`:""}
      <div class="hr"></div>
      <div class="actions"><button class="btn danger" type="button" data-action="delBP" data-id="${p.id}">Delete</button></div>
    </div>
  `).join("")||`<div class="muted">No purchases yet.</div>`;
  buyerPurchasesList.querySelectorAll("[data-action='delBP']").forEach(btn=>btn.addEventListener("click",()=>deleteBuyerPurchase(btn.dataset.id)));
}

// Settings: kennel + breeds
const kennelForm=document.getElementById("kennelForm");
const kennelName=document.getElementById("kennelName");
const kennelMode=document.getElementById("kennelMode");
const kennelInitials=document.getElementById("kennelInitials");
const kennelColor=document.getElementById("kennelColor");
const btnResetAll=document.getElementById("btnResetAll");
const breedForm=document.getElementById("breedForm");
const breedName=document.getElementById("breedName");
const metaBox=document.getElementById("metaBox");
kennelForm?.addEventListener("submit",(e)=>{
  e.preventDefault();
  state.kennel={name:kennelName.value.trim()||"Breeder Pro",mode:kennelMode.value,initials:(kennelInitials.value.trim()||"BP").slice(0,4),
    color:kennelColor.value.trim()||"#7dd3fc"};
  save();
});
btnResetAll?.addEventListener("click",()=>{ if(confirm("Reset ALL data on this device?")){ state=defaultState(); save(); } });
breedForm?.addEventListener("submit",(e)=>{
  e.preventDefault();
  const name=breedName.value.trim(); if(!name) return;
  const id=name.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/(^-|-$)/g,"").slice(0,32)||uid().slice(0,8);
  if(state.breeds.some(b=>b.id===id||b.name.toLowerCase()===name.toLowerCase())){ alert("That breed already exists."); return; }
  state.breeds.push({id,name,active:true}); breedForm.reset(); save();
});
function toggleBreed(id){
  const b=state.breeds.find(x=>x.id===id); if(!b) return;
  const activeCount=activeBreeds().length;
  if(b.id==="gsp" && activeCount<=1 && b.active!==false){ alert("Keep at least one active breed."); return; }
  b.active=(b.active===false)?true:false; save();
}
function deleteBreed(id){
  if(id==="gsp"){ alert("Baseline breed can't be deleted."); return; }
  const used=state.dogs.some(d=>d.breedId===id)||state.litters.some(l=>l.breedId===id)||state.waitlist.some(w=>w.desiredBreedId===id)||state.listings.some(l=>l.breedId===id);
  if(used){ alert("Breed is in use. Disable it instead."); return; }
  state.breeds=state.breeds.filter(b=>b.id!==id); save();
}
function renderBreeds(){
  if(!breedsList) return;
  breedsList.innerHTML=state.breeds.map(b=>`
    <div class="item">
      <div class="item-head">
        <div>
          <div class="item-title">${esc(b.name)}</div>
          <div class="item-sub">ID: ${esc(b.id)} • ${b.active===false?"Disabled":"Active"}</div>
        </div>
        <div class="badges"><span class="badge ${b.active===false?"":"brand"}">${b.active===false?"Disabled":"Active"}</span></div>
      </div>
      <div class="hr"></div>
      <div class="actions">
        <button class="btn ghost" type="button" data-action="breedToggle" data-id="${b.id}">${b.active===false?"Enable":"Disable"}</button>
        <button class="btn danger" type="button" data-action="breedDelete" data-id="${b.id}">Delete</button>
      </div>
    </div>
  `).join("");
  breedsList.querySelectorAll("[data-action='breedToggle']").forEach(btn=>btn.addEventListener("click",()=>toggleBreed(btn.dataset.id)));
  breedsList.querySelectorAll("[data-action='breedDelete']").forEach(btn=>btn.addEventListener("click",()=>deleteBreed(btn.dataset.id)));
}

// Dashboard
const countsBox=document.getElementById("countsBox");
const breedMixBox=document.getElementById("breedMixBox");
const followupsBox=document.getElementById("followupsBox");
function renderDashboard(){
  const dogs=state.dogs.length, litters=state.litters.length, listings=state.listings.length, inquiries=state.inquiries.length, wait=state.waitlist.length;
  countsBox.textContent=`Dogs:      ${dogs}\nLitters:    ${litters}\nListings:   ${listings}\nInquiries:  ${inquiries}\nBuyer wait: ${wait}\nUpdated:    ${new Date(state.meta.updatedAt).toLocaleString()}`;
  const mix=new Map(); state.dogs.forEach(d=>mix.set(d.breedId,(mix.get(d.breedId)||0)+1));
  const lines=[...mix.entries()].sort((a,b)=>b[1]-a[1]).map(([id,c])=>`${breedNameById(id)}: ${c}`);
  breedMixBox.textContent=lines.length?lines.join("\n"):"—";
  // followups: any inquiry/contacts without update in 30d — simple view
  const today=new Date();
  const stale=state.inquiries.slice(0,15).filter(i=>{
    const last=new Date(i.updatedAt||i.createdAt||nowISO());
    return ((today-last)/(1000*60*60*24))>=30;
  });
  followupsBox.textContent=stale.length?stale.map(i=>`${i.name||"Inquiry"} — ${i.email||"—"} (${i.status})`).join("\n"):"—";
}

// Export/Import
const btnExport=document.getElementById("btnExport");
const importFile=document.getElementById("importFile");
function download(filename,text){
  const blob=new Blob([text],{type:"application/json"});
  const url=URL.createObjectURL(blob);
  const a=document.createElement("a"); a.href=url; a.download=filename;
  document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}
btnExport?.addEventListener("click",()=>download(`breeder-pro-v2.1-${new Date().toISOString().slice(0,10)}.json`, JSON.stringify(state,null,2)));
importFile?.addEventListener("change",async(e)=>{
  const f=e.target.files?.[0]; if(!f) return;
  const text=await f.text(); const incoming=safeParse(text,null);
  if(!incoming||!incoming.meta||!Array.isArray(incoming.breeds)){ alert("Invalid backup file."); return; }
  if(confirm("Import replaces current data on this device. Continue?")){ state=incoming; save(); }
});

// Settings render
function renderSettings(){
  kennelName.value=state.kennel?.name||"";
  kennelMode.value=state.kennel?.mode||"Breeder";
  kennelInitials.value=state.kennel?.initials||"BP";
  kennelColor.value=state.kennel?.color||"#7dd3fc";
  hatBreeder.value=state.hats?.breeder||"On";
  hatSeller.value=state.hats?.seller||"On";
  hatBuyer.value=state.hats?.buyer||"On";
  metaBox.textContent=`Storage key: ${STORAGE_KEY}\nVersion: ${state.meta.version}\nCreated: ${new Date(state.meta.createdAt).toLocaleString()}\nUpdated: ${new Date(state.meta.updatedAt).toLocaleString()}`;
}

// Public export feed (for public.html)
function publicFeed(){
  const pubListings=state.listings.filter(l=>l.public==="Yes" && l.status!=="Closed");
  return {
    generatedAt: nowISO(),
    kennel: { name: state.kennel?.name||"Breeder Pro", mode: state.kennel?.mode||"Breeder" },
    listings: pubListings.map(l=>({
      id:l.id, type:l.type, breed:breedNameById(l.breedId), title:l.title, price:l.price||0, desc:l.desc||"",
      status:l.status
    }))
  };
}

// Write public.json on export as well (download only—GitHub Pages won't auto update)
btnExport?.addEventListener("click",()=>{
  // also download a public feed
  download(`public-feed-${new Date().toISOString().slice(0,10)}.json`, JSON.stringify(publicFeed(), null, 2));
});

// Render all
function renderAll(){
  applyBrand();
  applyHats();
  fillBreedSelects();
  renderDashboard();
  renderDogs();
  renderLitters();
  renderListings();
  renderInquiries();
  renderWaitlist();
  renderBuyerPurchases();
  renderBreeds();
  renderSettings();
  fillInquiryListing();
  refreshParentSelects();
}
renderAll();
