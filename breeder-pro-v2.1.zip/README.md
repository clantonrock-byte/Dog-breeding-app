# Breeder Pro (v2.1)
Breeder/Seller/Buyer hats (capabilities). Local-first PWA.

## Notes
- Public page is static: `public.html`.
- To populate public listings:
  1) In the app → Export (downloads `public-feed-YYYY-MM-DD.json`)
  2) Rename to `public-feed.json`
  3) Upload to repo root
  4) Public page loads it.

## Deploy
Repo Settings → Pages → Deploy from branch → main / (root)
