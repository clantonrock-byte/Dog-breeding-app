
Auto-update setup (fresh re-issue)

1) Ensure Settings → Pages → Source = GitHub Actions
2) Upload .github/workflows/pages.yml
3) Upload autoupdate.js and build.json to repo root
4) Add this ONE line before </body> in index.html:

   <script src="autoupdate.js"></script>

After each deploy, the app will auto-refresh within ~45 seconds.
